class CreateMerchantAccounts < ActiveRecord::Migration[5.0]
  def change
    create_table :merchant_accounts do |t|
      t.references :admin, foreign_key: true
      t.string :bank_name
      t.string :acc_number
      t.string :acc_name
      t.string :btc_wallet

      t.timestamps
    end
  end
end
