class AddNewFieldsToAdmins < ActiveRecord::Migration[5.0]
  def change
    add_column :admins, :dollar_rate, :integer
    add_column :admins, :naira_rate, :integer
  end
end
