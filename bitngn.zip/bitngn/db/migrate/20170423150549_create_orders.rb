class CreateOrders < ActiveRecord::Migration[5.0]
  def change
    create_table :orders do |t|
      t.string :type
      t.string :order_hash
      t.references :user, foreign_key: true
      t.decimal :currency_amount
      t.integer :naira_amount
      t.string :receiving_address
      t.integer :conversion_rate

      t.timestamps
    end
  end
end
