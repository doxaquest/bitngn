class AddNairaSellRateToAdmins < ActiveRecord::Migration[5.0]
  def change
  	add_column :admins, :naira_sell_rate, :integer
  end
end
