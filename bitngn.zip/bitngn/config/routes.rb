Rails.application.routes.draw do

  get 'admin_dashboard', to: 'admin_dashboard#index', as: 'admin_dashboard'
  get 'admin_dashboard/manage_orders', to: 'admin_dashboard#manage_orders', as: 'admin_manage_orders'
  get 'admin_dashboard/manage_order/:id', to: 'admin_dashboard#manage_order', as: 'admin_manage_order'
  get 'admin_dashboard/manage_orders/update_order', to: 'admin_dashboard#update_order_status', as: 'update_order_status'
  get 'admin_dashboard/manage_users', to: 'admin_dashboard#manage_users', as: 'admin_manage_users'
  get 'admin_dashboard/manage_conversion_rates', to: 'admin_dashboard#manage_conversion_rates', as: 'admin_manage_conversion'
  post 'manage_conversion_rates', to: 'admin_dashboard#manage_conversion_rates', as: 'manage_conversion'

  get 'admin_dashboard/manage_orders/search', to: 'admin_dashboard#manage_orders', as: 'admin_search_order'

  get 'admin_dashboard/account_settings', to: 'admin_dashboard#settings', as: 'merchant_settings'


  devise_for :admins
  resources :orders

  devise_for :users


  resources :accounts, only: [:new, :create, :edit, :update]

  resources :merchant_accounts, only: [:new, :create, :edit, :update]

  get '/dashboard/settings', to: 'dashboard#settings', as: 'settings'


  get '/dashboard', to: 'dashboard#index', as: 'dashboard'
  
  root 'pages#index'

  get '/terms', to: 'pages#terms', as: 'terms'

  get 'pages/contact'

  get '/orders/confirm_payment/:order_id', to: 'orders#confirm_payment', as: "confirm_order_payment"

  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
