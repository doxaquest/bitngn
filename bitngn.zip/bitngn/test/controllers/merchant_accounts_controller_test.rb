require 'test_helper'

class MerchantAccountsControllerTest < ActionDispatch::IntegrationTest
  test "should get new" do
    get merchant_accounts_new_url
    assert_response :success
  end

  test "should get create" do
    get merchant_accounts_create_url
    assert_response :success
  end

end
