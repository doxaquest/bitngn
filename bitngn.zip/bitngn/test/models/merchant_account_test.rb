require 'test_helper'

class MerchantAccountTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
