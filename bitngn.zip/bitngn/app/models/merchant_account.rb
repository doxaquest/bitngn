class MerchantAccount < ApplicationRecord
  belongs_to :admin

  validates :bank_name, :acc_number, :acc_name, :btc_wallet, presence: true
end
