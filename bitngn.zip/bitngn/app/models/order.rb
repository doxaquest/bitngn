class Order < ApplicationRecord

  
  default_scope  { order(:created_at => :desc) }

  belongs_to :user

  validates :currency_amount, :naira_amount, :receiving_address, presence: true
end
