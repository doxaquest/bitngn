class PagesController < ApplicationController

layout "pages"

  def index
  	
  end

  def terms
  end

  def contact
  end
end
