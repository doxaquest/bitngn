class DashboardController < ApplicationController
	before_action :authenticate_user!
	
  def index
    @orders = Order.all.limit(10)
  end

  def settings
  	if current_user.account.nil? 
  		@account = Account.new(user_id: current_user)
  	else
	  	@account = current_user.account 
	 end

	 @buy_orders_count = current_user.orders.where(category: 'buy').count 
	 @sell_orders_count = current_user.orders.where(category: 'sell').count
  end

end
