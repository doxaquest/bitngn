class MerchantAccountsController < ApplicationController
  
  def new
  end

  def create
    admin_id = params[:admin_id]

     if MerchantAccount.create(account_params)
      flash[:success] = "Account Details updated successfully"
      redirect_to merchant_settings_path
    else
      flash[:error] = "There was an error updating the account records"
      redirect_to merchant_settings_path
    end
  end

  def edit
  end

  def update
  	@merchant_account = MerchantAccount.find(params[:id])

  	if @merchant_account.update(account_params)
  		flash[:success] = "Account Details successfully Updated"
  		redirect_to merchant_settings_path
  	else
  		flash[:error] = "Update Failed. try again with correct Account Details"
  		redirect_to merchant_settings_path
  	end
  end

  def destroy
  end

private
  def account_params
    params.require(:merchant_account).permit(:bank_name, :acc_name, :acc_number, :btc_wallet, :admin_id)
  end
end
