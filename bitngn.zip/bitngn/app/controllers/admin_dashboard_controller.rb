class AdminDashboardController < ApplicationController

	layout 'admin'

  def index
     @orders = Order.all.limit(10)
  end


  def manage_orders
    if params[:search_term]
      search_term = params[:search_term]
      @orders = Order.where(order_hash: search_term)

    else

      	 if params[:order_cat] == "sell"
          @orders = Order.where(category: "sell")
        elsif params[:order_cat] == "buy" 
          @orders = Order.where(category: "buy")
        else
          @orders = Order.all 
        end
    end

  end


  def settings
    if current_admin.merchant_account.nil?
      @merchant_account = MerchantAccount.new(admin_id: current_admin.id )
    else
      @merchant_account = current_admin.merchant_account
   end
  end

  def manage_order
  	 @order = Order.find(params[:id])
  end

  def manage_users
  	@users = User.all
  end

  def manage_conversion_rates
  	@admin = current_admin

  	@dollar_rate = @admin.dollar_rate
  	@naira_rate = @admin.naira_rate
    @naira_sell_rate = @admin.naira_sell_rate

  	
  	if params[:dollar_rate] && params[:naira_rate]
	  	@dollar_rate = params[:dollar_rate]
	  	@naira_rate = params[:naira_rate]
      @naira_sell_rate = params[:naira_sell_rate]

	  	if @admin.update(:dollar_rate => @dollar_rate, :naira_rate => @naira_rate, :naira_sell_rate => @naira_sell_rate)
	  		flash[:success] = "Currency conversion rates updated successfully"
	  		redirect_to admin_manage_conversion_path
	  	else
	  		flash[:error] = "There was an error updating conversion rates"
	  	end
	  end
  end

  def update_order_status
  	order = Order.find(params[:id])
  	status =  params[:status]

  	if order.update(status: status)
  		flash[:success] = "Order status updated successfully :)"
  		redirect_to admin_manage_order_path(id: order.id)
  	else
  		flash[:error] = "There was a problem updating the status of this order"
  		render 'manage_order'
  	end

  end
end
