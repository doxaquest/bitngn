class AccountsController < ApplicationController

  def new
  end

  def create
    user_id = params[:user_id]

     if Account.create(account_params)
      flash[:success] = "Account Details updated successfully"
      redirect_to settings_path
    else
      flash[:error] = "There was an error updating the account records"
      redirect_to settings_path
    end
  end

  def edit
  end

  def update
    @account = Account.find(params[:id])

    if @account.update(account_params)
      flash[:success] = "Account Details successfully Updated"
      redirect_to settings_path
    else
      flash[:error] = "Update Failed. try again with correct Account Details"
      redirect_to settings_path
    end
  end

  def destroy
  end

private
  def account_params
    params.require(:account).permit(:bank_name, :acc_name, :acc_number, :btc_wallet, :user_id)
  end
end
