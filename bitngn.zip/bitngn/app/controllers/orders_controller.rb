class OrdersController < ApplicationController

before_action :authenticate_user!

  def index
    if params[:show] == "sell"
      @orders = current_user.orders.where(category: "sell")
    elsif params[:show] == "buy" 
      @orders = current_user.orders.where(category: "buy")
    else
      @orders = current_user.orders 
    end
  end


  def new
    @order = current_user.orders.build

    if params[:order_cat] == "sell"
      @order_category = "sell"
    else
      @order_category = "buy"
    end

      @dollar_rate = Admin.first.dollar_rate
      @naira_rate = Admin.first.naira_rate
      @naira_sell_rate = Admin.first.naira_sell_rate
  
    end

  def create

    @order = current_user.orders.new(order_params)

    if @order.save
      flash[:notice] = "Order created successfully. "
      redirect_to @order
    else 
      flash[:error] = "There was a problem creating your order"
      redirect_to new_order_path
    end
  end

  def update
  end

  def show
    @order = Order.find(params[:id])
    
    @merchant_account = Admin.first.merchant_account
  end

  def confirm_payment
    if params[:order_id]
      order = Order.find(params[:order_id])
      order.update(payment_status: 'paid')
      flash[:success] = "Thank you. we are processing your order"
      redirect_to order
    else
      flash[:error] = "You cant go here please"
      redirect_to order
    end
  end

  def destroy
  end

  private

  def order_params
    params.require(:order).permit(:status, :payment_status, :category, :currency_amount, :naira_amount, :receiving_address, :order_type, :order_hash)

  end
end
