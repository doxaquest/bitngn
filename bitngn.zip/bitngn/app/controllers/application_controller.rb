class ApplicationController < ActionController::Base
  protect_from_forgery with: :exception


  layout :layout_by_resource

  before_action :configure_permitted_parameters, if: :devise_controller?




  private

  def configure_permitted_parameters
  		devise_parameter_sanitizer.permit(:sign_up, keys: [:fullname, :phone])
  end

  
  def layout_by_resource
    if devise_controller? 
      "auth_pages"
    end
  end


  def after_sign_in_path_for(resource)
    if current_user
    	dashboard_path
    else
      admin_dashboard_path
    end
  end
end
